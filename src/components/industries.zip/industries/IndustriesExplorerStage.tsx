"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useInView, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Icon } from "@/components/ui";
import type { IndustryPresentation } from "./industryPresentation";
import styles from "./IndustriesExplorerStage.module.css";

type IndustryView = { slug: string; presentation: IndustryPresentation };
const vehicleOrder = ["cab-taxi", "school-transport", "trucking-logistics", "public-transport", "employee-transport", "mining", "agriculture"];
const edges = [0, 280, 585, 910, 1203, 1499, 1845, 2125];

function Vehicle({ slug }: { slug: string }) {
  const index = Math.max(0, vehicleOrder.indexOf(slug));
  return <svg className={styles.vehicleImage} viewBox={`${edges[index]} 215 ${edges[index + 1] - edges[index]} 300`} aria-hidden="true">
    <image href="/media/industries/gallery/vehicle-stage-atlas.png" width="2125" height="740" />
  </svg>;
}

export default function IndustriesExplorerStage({ industries }: { industries: IndustryView[] }) {
  const ordered = useMemo(() => [...industries].sort((a, b) => vehicleOrder.indexOf(a.slug) - vehicleOrder.indexOf(b.slug)), [industries]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const section = useRef<HTMLElement>(null);
  const rail = useRef<HTMLDivElement>(null);
  const inView = useInView(section, { amount: .2 });
  const reduceMotion = useReducedMotion();
  const active = ordered[activeIndex] ?? ordered[0];

  useEffect(() => {
    if (paused || reduceMotion || !inView || ordered.length < 2) return;
    const timer = window.setInterval(() => setActiveIndex(index => (index + 1) % ordered.length), 4000);
    return () => window.clearInterval(timer);
  }, [paused, reduceMotion, inView, ordered.length]);

  function select(index: number, scroll = false) {
    const next = (index + ordered.length) % ordered.length;
    setActiveIndex(next);
    if (scroll && rail.current) {
      const button = rail.current.querySelectorAll<HTMLButtonElement>("[data-vehicle]")[next];
      if (button) rail.current.scrollTo({ left: button.offsetLeft - rail.current.clientWidth / 2 + button.clientWidth / 2, behavior: reduceMotion ? "instant" : "smooth" });
    }
  }

  if (!active) return null;
  return <section ref={section} id="industry-explorer" className={styles.explorer} aria-labelledby="industry-explorer-title"
    onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(section.current?.contains(document.activeElement) ?? false)}
    onFocusCapture={() => setPaused(true)} onBlurCapture={event => { if (!event.currentTarget.contains(event.relatedTarget)) setPaused(false); }}>
    <header className={styles.heading}>
      <p className={styles.eyebrow}>Industries we serve</p>
      <h2 id="industry-explorer-title">Different Fleets. <span>A Smarter Tomorrow.</span></h2>
      <p>Tailored solutions for every industry, keeping your people, assets and operations moving safely and efficiently.</p>
    </header>
    <div ref={rail} className={styles.viewport}>
      <div className={styles.stage}>
        <div className={styles.vehicles}>
          {ordered.map((industry, index) => <button type="button" data-vehicle={industry.slug} key={industry.slug}
            className={styles.vehicle} aria-label={`Select ${industry.presentation.navName}`} aria-pressed={active.slug === industry.slug}
            onMouseEnter={() => select(index)} onFocus={() => select(index)} onClick={() => select(index)}>
            <span className={styles.cutout}><Vehicle slug={industry.slug} /></span>
            <span className={styles.label}><span className={styles.icon}><Icon name={industry.presentation.icon} /></span><strong>{industry.presentation.navName}</strong></span>
          </button>)}
        </div>
      </div>
    </div>
    <div className={styles.toolbar}>
      <div className={styles.controls}>
        <button type="button" aria-label="Previous industry" onClick={() => select(activeIndex - 1, true)}><ArrowLeft /></button>
        <div className={styles.dots}>{ordered.map((industry, index) => <button type="button" key={industry.slug} aria-label={`Show ${industry.presentation.navName}`} aria-pressed={active.slug === industry.slug} onClick={() => select(index, true)} />)}</div>
        <button type="button" aria-label="Next industry" onClick={() => select(activeIndex + 1, true)}><ArrowRight /></button>
      </div>
      <a className={styles.explore} href="#industries-in-action">Explore Industries <ArrowRight size={18} /></a>
    </div>
    <div className={styles.detail}>
      <div className={styles.detailVehicle}><Vehicle slug={active.slug} /></div>
      <div className={styles.detailCopy}>
        <p className={styles.eyebrow}>{active.presentation.navName}</p>
        <h3>{active.presentation.shortLine}</h3>
        <Link className={styles.solution} href={`/industries/${active.slug}`}>Explore Solution <ArrowRight size={18} /></Link>
      </div>
      <div className={styles.benefits}>{active.presentation.storyBenefits.slice(0, 3).map(benefit => <div key={benefit.title}><span className={styles.icon}><Icon name={benefit.icon} /></span><p>{benefit.title}</p></div>)}</div>
    </div>
  </section>;
}
