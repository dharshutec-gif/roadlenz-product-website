"use client";

import { useMemo } from "react";
import Link from "next/link";
import { motion } from "framer-motion";

import type { Industry } from "@/lib/types";
import { Icon } from "@/components/ui";

import {
  getIndustryPresentation,
  getOrderedIndustryRecords,
  type IndustryPresentation,
} from "./industryPresentation";

import IndustryIntelligenceSection from "./IndustryIntelligenceSection";
import IndustriesHero from "./IndustriesHero";
import IndustriesActionGallery from "./IndustriesActionGallery";
import IndustriesExplorerStage from "./IndustriesExplorerStage";

import styles from "./IndustriesExperience.module.css";
import typography from "./IndustriesTypography.module.css";

type Props = {
  industries: Industry[];
};

type IndustryView = Industry & {
  presentation: IndustryPresentation;
};

const reveal = {
  initial: {
    opacity: 0,
    y: 16,
  },

  whileInView: {
    opacity: 1,
    y: 0,
  },

  viewport: {
    once: true,
    amount: 0.18,
  },
};

export default function IndustriesExperience({
  industries,
}: Props) {

  const ordered = useMemo(
    () =>
      getOrderedIndustryRecords(industries)
        .map((industry) => {
          const presentation =
            getIndustryPresentation(industry.slug);

          return presentation
            ? ({
                ...industry,
                presentation,
              } as IndustryView)
            : null;
        })
        .filter(
          (
            item,
          ): item is IndustryView =>
            Boolean(item),
        ),
    [industries],
  );

  if (!ordered.length) {
    return (
      <section
        className={
          styles.emptyState
        }
      >
        <Icon name="route" />

        <h1>
          Industries are being
          prepared.
        </h1>

        <p>
          Talk to RoadLenz about
          your fleet operation.
        </p>

        <Link href="/contact">
          Contact our team
        </Link>
      </section>
    );
  }

  return (
    <main className={`${styles.page} ${typography.typography}`}>
      {/* =======================
          HERO
      ======================= */}

      <IndustriesHero />

      {/* =======================
          INDUSTRY MARQUEE
      ======================= */}

      <IndustriesExplorerStage industries={ordered} />

      {/* =======================
          INDUSTRIES IN ACTION
      ======================= */}

      <section
        id="industries-in-action"
        className={styles.actionSection}
        aria-labelledby="industries-action-title"
      >
        <div
          className={
            styles.montageCopy
          }
        >
          <motion.p
            {...reveal}
            className={
              styles.eyebrow
            }
          >
            Industries in action
          </motion.p>

          <motion.h2
            {...reveal}
            id="industries-action-title"
          >
            Different roads.
            <br />
            A common purpose.
          </motion.h2>

          <motion.p {...reveal}>
            From city mobility to
            remote operations,
            RoadLenz helps teams
            keep vehicles, people
            and assets connected
            across every terrain.
          </motion.p>

          <motion.a
            {...reveal}
            href="#industry-explorer"
          >
            Discover how we make
            an impact

            <Icon name="arrowRight" />
          </motion.a>
        </div>

        <IndustriesActionGallery industries={ordered} />
      </section>

      {/* NEW 3D INTELLIGENCE CORE */}

      <IndustryIntelligenceSection />

      {/* =======================
          PLATFORM VALUES
      ======================= */}

      <section
        className={styles.results}
        aria-labelledby="results-title"
      >
        <motion.div
          {...reveal}
          className={
            styles.resultsIntro
          }
        >
          <p
            className={
              styles.eyebrow
            }
          >
            Real operations
          </p>

          <h2 id="results-title">
            Built to support
            <br />
            diverse fleets.
          </h2>

          <p>
            RoadLenz connects
            location, video and
            operational intelligence
            so fleet teams can work
            with a clearer picture
            of what is happening.
          </p>
        </motion.div>

        <div
          className={
            styles.resultStats
          }
        >
          {[
            [
              "eye",
              "Live Visibility",
              "Know where vehicles are and what is happening.",
            ],

            [
              "video",
              "Video Intelligence",
              "Bring live and recorded video into fleet context.",
            ],

            [
              "shield",
              "Safety & Alerts",
              "Surface critical events and operational exceptions.",
            ],

            [
              "doc",
              "Reports & Analytics",
              "Turn activity into clear operational intelligence.",
            ],
          ].map(
            (
              [
                icon,
                title,
                copy,
              ],
              index,
            ) => (
              <motion.div
                key={title}
                initial={{
                  opacity: 0,
                  y: 16,
                }}
                whileInView={{
                  opacity: 1,
                  y: 0,
                }}
                viewport={{
                  once: true,
                  amount: 0.3,
                }}
                transition={{
                  delay:
                    index *
                    0.08,

                  duration:
                    0.45,
                }}
                whileHover={{
                  y: -5,
                }}
              >
                <span
                  className={
                    styles.resultIcon
                  }
                >
                  <Icon
                    name={icon}
                  />
                </span>

                <strong>
                  {title}
                </strong>

                <small>
                  {copy}
                </small>
              </motion.div>
            ),
          )}
        </div>

        <motion.blockquote
          {...reveal}
          className={
            styles.quoteCard
          }
        >
          <Icon name="eye" />

          <p>
            One connected RoadLenz
            view helps operations
            teams bring vehicle
            movement, alerts, video
            context and reporting
            together instead of
            checking disconnected
            systems.
          </p>

          <footer>
            RoadLenz Fleet
            Intelligence Platform
          </footer>
        </motion.blockquote>
      </section>

      {/* =======================
          CTA
      ======================= */}

      <section
        className={styles.cta}
        aria-labelledby="industries-cta-title"
      >
        <div
          className={
            styles.ctaBackdrop
          }
          aria-hidden="true"
        />

        <div
          className={
            styles.ctaInner
          }
        >
          <div>
            <p
              className={
                styles.eyebrow
              }
            >
              Ready to transform
              your industry?
            </p>

            <h2 id="industries-cta-title">
              Let’s build a{" "}
              <em>
                safer,
                <br />
                smarter tomorrow.
              </em>
            </h2>

            <p>
              Tell us how your fleet
              operates. We’ll show
              you how RoadLenz can
              fit into your
              operation.
            </p>

            <div
              className={
                styles.ctaActions
              }
            >
              <Link
                href="/book-demo"
                className={
                  styles.primaryButton
                }
              >
                Request a Demo

                <Icon name="arrowRight" />
              </Link>

              <Link
                href="/contact"
                className={
                  styles.secondaryButton
                }
              >
                Contact Our Team
              </Link>
            </div>
          </div>

          <ul>
            <li>
              <Icon name="shield" />
              Safer Operations
            </li>

            <li>
              <Icon name="fleet" />
              Connected Fleets
            </li>

            <li>
              <Icon name="gauge" />
              Smarter Decisions
            </li>

            <li>
              <Icon name="leaf" />
              Sustainable Growth
            </li>
          </ul>
        </div>
      </section>
    </main>
  );
}
